
var btn = document.getElementById("btn");
var point = -1;
var totalPoints;
var lol = 20;
var pC = document.getElementById("pointCounter");

btn.addEventListener("click", function() {
  btn.value = ""
  btn.style.width = "5px";
  btn.style.height = "10px";
  btn.style.top = Math.floor((Math.random() * 230) + 1) + "px";
  btn.style.left = Math.floor((Math.random() * 500) + 1) + "px";
  point++;
	pC.innerHTML = point;
});



